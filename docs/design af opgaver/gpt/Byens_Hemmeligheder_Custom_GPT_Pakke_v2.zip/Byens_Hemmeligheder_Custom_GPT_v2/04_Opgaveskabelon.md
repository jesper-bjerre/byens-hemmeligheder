# Opgaveskabelon – Byens Hemmeligheder

Kopiér skabelonen til en ny fil eller brug den som input til Custom GPT'en.

---

# [Sted] – [Opgavetitel]

**Status:** Idé / Researchklar / Udkast / Felttestklar / Publiceringsklar  
**Version:**  
**Quizmaster:**  
**Dato:**  
**Senest fysisk verificeret:**  

## Metadata

| Felt | Værdi |
|---|---|
| Område | |
| Overordnet historie | |
| Kapitelrolle | Intro / mellemkapitel / vendepunkt / finale / selvstændig |
| Sværhedsgrad | 1–5 |
| Type | |
| Målgruppe | 10–15 år og familie |
| Forventet varighed | |
| Grundpoint | |
| Inventory krævet | |
| Inventory-belønning | |
| Facitformat | Tal / tekst / valg / rækkefølge / andet |
| Facit | |

---

## 1. Hvorfor stedet egner sig

## 2. Kilder og faktuelle påstande

| Påstand | Kilde | Sikkerhed | Må bruges i facit? |
|---|---|---|---|
| | | | |

## 3. Fakta og fiktion

**Dokumenteret fakta:**

**Fiktiv ramme:**

**Tekst, der vises til spilleren om fiktion:**

## 4. Spillerstandpunkt

**Adresse:**  
**Koordinater:**  
**Aktiveringsradius:**  
**Instruktion:**  
**Hvad kan ses:**  
**Referencefoto:**  
**Årstids- eller lysproblemer:**  

## 5. Narrativ intro

## 6. Opgaven trin for trin

### Trin 1

### Trin 2

### Trin 3

## 7. Facit og løsningsbevis

Beskriv alle mellemtrin. Forklar, hvorfor facit er entydigt.

## 8. Accepterede svar

## 9. Forkerte svar og feedback

| Forkert svar eller fejltype | Feedback |
|---|---|
| | |

## 10. Hints

### Hint 1 – lille skub, -3 %

### Hint 2 – konkret hjælp, yderligere -4 %

### Hint 3 – næsten løsningen, yderligere -5 %

## 11. Belønning og progression

**Point:**  
**Inventory:**  
**Ny viden:**  
**Næste spor:**  

## 12. iOS- og webflow

1. Kort/opgavekort
2. Intro
3. Standpunkt
4. Spor
5. Hint
6. Svar
7. Resultat
8. Belønning

Skriv den præcise tekst og alle knapper til hver skærm.

## 13. Sikkerhed

## 14. Tilgængelighed

## 15. Medier og rettigheder

## 16. Felttest

| Test | Resultat | Ændring |
|---|---|---|
| Intern solve-test | | |
| Faglig review | | |
| Feltbesøg | | |
| Målgruppetest | | |
| Familietest | | |
| Hinttest | | |

## 17. Quizmasterens åbne opgaver

- [ ]

## 18. Kvalitetsscore

| Kriterium | 1–5 | Kommentar |
|---|---:|---|
| Lokationsrelevans | | |
| Historisk kvalitet | | |
| Fysisk spor | | |
| Entydighed | | |
| Underholdning | | |
| Familiesamarbejde | | |
| Sværheds-match | | |
| Hint-egnethed | | |
| Sikkerhed | | |
| Helårsrobusthed | | |
| Historieintegration | | |
| UX-egnethed | | |

## 19. Publiceringsport

- [ ] Fysisk besøgt
- [ ] Observation verificeret
- [ ] Facit dokumenteret
- [ ] Løsningsbevis entydigt
- [ ] Hints testet
- [ ] Sikkerhed godkendt
- [ ] Fakta og fiktion adskilt
- [ ] Medierettigheder afklaret
- [ ] Målgruppetest gennemført
- [ ] Alle skærme har samme facit
- [ ] Redaktørgodkendelse

## 20. JSON-eksport

```json
{
  "title": "",
  "location": {
    "name": "",
    "address": "",
    "latitude": null,
    "longitude": null,
    "activationRadiusMeters": null,
    "vantagePointInstruction": ""
  },
  "status": "draft",
  "difficulty": null,
  "targetAge": "10-15",
  "estimatedMinutes": null,
  "challengeType": [],
  "storyContext": {
    "area": "",
    "story": "",
    "chapterRole": "",
    "fictionLabel": ""
  },
  "playerIntro": "",
  "steps": [],
  "answer": {
    "format": "",
    "canonical": "",
    "acceptedAlternatives": [],
    "solutionProof": ""
  },
  "hints": [],
  "wrongAnswerFeedback": [],
  "basePoints": null,
  "inventoryRequired": [],
  "inventoryReward": [],
  "safety": [],
  "accessibility": [],
  "sources": [],
  "mediaRights": [],
  "fieldTestChecklist": [],
  "quizmasterOpenTasks": [],
  "lastPhysicallyVerified": null
}
```
