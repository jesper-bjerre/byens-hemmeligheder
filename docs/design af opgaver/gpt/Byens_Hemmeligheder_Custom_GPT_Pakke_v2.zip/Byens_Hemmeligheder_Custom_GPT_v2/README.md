# Byens Hemmeligheder – Custom GPT-pakke

Denne mappe indeholder alt, der skal bruges til at oprette Custom GPT'en:

**Byens Hemmeligheder – Quizmaster**

## Hurtig start

1. Læs `06_Opsaetning_og_Test.md`.
2. Opret GPT'en i ChatGPT på web.
3. Kopiér `02_Custom_GPT_Instructions.md` ind i feltet Instructions.
4. Upload fil 01, 03, 04, 05 og 07 som Knowledge.
5. Aktivér Web Search, Image Generation og Code Interpreter & Data Analysis.
6. Test med prompts fra opsætningsfilen.

## Filer

- `01_...Projektgrundlag.md`: autoritativ viden om hele projektet
- `02_...Instructions.md`: GPT'ens regler og workflow
- `03_Quizmastermanual.md`: praktisk viden om opgaveproduktion
- `04_Opgaveskabelon.md`: fast output- og dataskabelon
- `05_Gold_Standard_Boelgen.md`: konsistent eksempel med facit og løsningsbevis
- `06_Opsaetning_og_Test.md`: felter, capabilities, test og deling
- `07_Retningslinjer_Escape_Room_Opgavedesign.md`: researchbaseret metodeguide og bindende puzzle-regler
- `08_Kort_Prompt_til_GPT_Builder.md`: kort prompt til den samtalebaserede builder

## Vigtigt

GPT'en kan skabe et stærkt og næsten færdigt opgaveudkast, men den kan ikke erstatte:

- fysisk besøg
- sikkerhedsvurdering
- kontrol af synlighed
- billed- og medierettigheder
- faktuel godkendelse
- målgruppetest
- endelig redaktørgodkendelse
