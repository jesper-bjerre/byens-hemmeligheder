# Byens Hemmeligheder

## Retningslinjer for design af stedsspecifikke escape room-opgaver

**Målgruppe:** Frivillige quizmastere, redaktører, museer, turistaktører og undervisere  
**Anvendelse:** Metodeguide og vidensfil til Custom GPT'en *Byens Hemmeligheder – Quizmaster*  
**Version:** 1.0  
**Pilotområde:** Vejle  
**Primær spillermålgruppe:** 10–15 år og familier  

---

# 1. Formålet med disse retningslinjer

Byens Hemmeligheder skal ikke blot være en app med spørgsmål placeret på et kort. Oplevelsen skal føles som et **escape room i den virkelige verden**, hvor stedet, historien og gåden er uløseligt forbundet.

En vellykket opgave får spilleren til at:

1. lægge telefonen lidt væk og se på stedet
2. opdage noget, der ikke blev bemærket ved første øjekast
3. forstå en regel eller sammenhæng
4. kombinere flere spor
5. opleve et tydeligt “aha”
6. få en belønning, som fører historien videre

Retningslinjerne bygger på gennemgående principper fra escape room-design, puzzle design, location-based games, museumsformidling, brugerinddragelse og outdoor-spil:

- sted, fortælling og mekanik skal hænge sammen
- facit skal kunne bevises
- sværhedsgrad skal komme fra tænkning, ikke uklarhed
- hints skal genoprette fremdrift uden at ødelægge oplevelsen
- opgaver skal testes iterativt
- fysiske forhold skal verificeres af et menneske

Den vigtigste hovedregel er:

> **Hvis facit ikke kan bevises trin for trin på papir, kan opgaven ikke publiceres i appen.**

---

# 2. Hvad er en escape room-opgave?

En escape room-opgave er en struktureret udfordring, hvor spilleren finder eller modtager information, opdager en regel og anvender den til at skabe et entydigt resultat.

En komplet opgave består af seks dele:

| Del | Funktion | Eksempel |
|---|---|---|
| Signal | Viser, at noget er relevant | Et symbol fremhæves i appen |
| Spor | Leverer information | Fem bølgetoppe kan ses |
| Regel | Forklarer, hvad informationen betyder | “Læs hav → højde → historie” |
| Handling | Det spilleren gør | Tæller, sorterer eller kombinerer |
| Facit | Entydigt resultat | Koden `592` |
| Feedback | Bekræfter forståelsen | Beskeden åbnes og forklarer løsningen |

Hvis en af disse dele mangler, opstår typiske problemer:

- spilleren ved ikke, hvad der er vigtigt
- flere regler virker lige plausible
- løsningen kræver gæt
- facit føles vilkårligt
- hints kan ikke rette misforståelsen
- quizmasteren må forklare løsningen mundtligt

---

# 3. Den grundlæggende puzzle-loop

En god opgave følger normalt dette forløb:

## 3.1 Opdag

Spilleren opdager et relevant fysisk eller digitalt spor.

Eksempel:

> “Der er fem tydelige bølgetoppe i byggeriet.”

## 3.2 Forstå

Spilleren forstår, hvilken afgrænsning eller regel der gælder.

Eksempel:

> “Tæl kun de store hvide hovedformer – ikke vinduer eller altaner.”

## 3.3 Bearbejd

Spilleren sorterer, kombinerer, oversætter eller beregner.

Eksempel:

> Fem bølger + ni etager + to bølger før pausen.

## 3.4 Bekræft

Spilleren får et resultat, der kan indtastes eller vælges.

Eksempel:

> `592`

## 3.5 Beløn

Appen forklarer kort, hvorfor resultatet er rigtigt, og flytter historien fremad.

Eksempel:

> Spilleren får inventory-genstanden **Det femte signal**.

Et godt “aha” opstår ofte mellem **forstå** og **bearbejd**. Spilleren ser pludselig, hvordan tilsyneladende adskilte spor hænger sammen.

---

# 4. De tre lag: sted, fortælling og regel

Alle opgaver bør designes i tre sammenhængende lag.

## 4.1 Stedet

Stedet leverer noget observerbart:

- form
- antal
- retning
- rækkefølge
- tekst
- årstal
- relation mellem objekter
- udsigt
- lyd
- historisk kontrast

## 4.2 Fortællingen

Fortællingen giver motivation og mening:

- hvorfor skal dette undersøges?
- hvem har efterladt sporet?
- hvorfor er rækkefølgen vigtig?
- hvad låses op?
- hvordan indgår resultatet i den større historie?

## 4.3 Reglen

Reglen gør facit udledeligt:

- hvad skal tælles?
- hvad skal ignoreres?
- hvilken rækkefølge anvendes?
- hvordan oversættes symbolerne?
- hvilke delresultater kombineres?

### God integration

> En gammel havneingeniør har efterladt tre symboler: hav, højde og historie. De fortæller rækkefølgen for tre verificerede tal ved Bølgen.

### Svag integration

> Læs en lang historie om havnen, og svar derefter på et almindeligt multiple choice-spørgsmål, som kunne besvares hjemmefra.

Fortælling må ikke være pynt. Den bør enten:

- pege på sporet
- forklare reglen
- fastlægge rækkefølgen
- give en nødvendig oplysning
- forklare belønningen

---

# 5. Observerbare invariants

Outdoor-opgaver bør bygges på **observerbare invariants**: egenskaber, der er stabile, tydelige og sandsynligvis stadig findes om flere år.

## 5.1 Gode invariants

- bygningens fem hoveddele
- en permanent inskription
- fire faste skulpturer
- en dokumenteret retning mellem monumenter
- antal faste brofag
- et udskåret årstal
- en stabil landskabsformation
- rækkefølgen af permanente elementer
- officielle historiske data, der gives i appen

## 5.2 Svage eller farlige spor

- antal parkerede biler
- refleksioner i vand eller glas
- midlertidige skilte
- løse bænke
- blomster eller vegetation
- antallet af personer
- en butiks navn
- et kunstværk, der flyttes sæsonmæssigt
- noget, der kun kan ses i én bestemt belysning
- AI-tegnede silhuetter uden validering

## 5.3 Stabilitetskontrol

Quizmasteren skal spørge:

- Kan dette ændre sig efter renovering?
- Kan vegetation skjule det?
- Kan sne, mørke eller regn gøre det ulæseligt?
- Kan det ses fra det sikre standpunkt?
- Kan to personer tælle forskelligt?
- Kan stedet være lukket?
- Er det afhængigt af en udstilling eller åbningstid?

Hvis svaret er ja, skal der enten vælges et mere robust spor eller tilføjes en revisionsdato og fallback.

---

# 6. Puzzle-arkitektur

En rute består ikke kun af individuelle gåder. Opgaverne skal organiseres, så spillerne oplever progression uden unødvendige flaskehalse.

## 6.1 Lineær struktur

```text
Opgave A → Opgave B → Opgave C → Finale
```

**Fordel:** Nem historie og tydelig progression.  
**Risiko:** Hvis spillerne sidder fast, stopper alt.

God til korte begynderruter med stærke hints.

## 6.2 Parallel struktur

```text
        → Opgave A →
Start   → Opgave B → Meta-opgave
        → Opgave C →
```

**Fordel:** Familien kan vælge rækkefølge og skifte opgave ved fastlåsning.  
**Risiko:** Kræver tydelig opsamling af delresultater.

God til åbne byområder.

## 6.3 Forgrenet struktur

Spillerens valg åbner forskellige spor eller rækkefølger.

**Fordel:** Følelse af frihed.  
**Risiko:** Højere kompleksitet, mere indhold og sværere test.

Bør normalt komme efter MVP.

## 6.4 Meta-puzzle

Flere opgaver giver delresultater, som samles i en finale.

Eksempel:

- Fjordenhus giver symbolet **Vand**
- Bølgen giver symbolet **Form**
- Vejle Å giver symbolet **Retning**
- Finalen bruger de tre symboler til at åbne et kort

Meta-puzzles er stærke, fordi de skaber helhed. De kræver dog:

- tydelig mærkning af delresultater
- inventory eller automatisk opsamling
- en finale, der forklarer hvordan delene kombineres
- mulighed for at genfinde tidligere resultater

## 6.5 Undgå single-point-of-failure

En hel rute bør ikke blokere permanent, fordi:

- et skilt er væk
- GPS ikke virker
- én svær opgave ikke kan løses
- et sted er midlertidigt lukket

Brug:

- progressive hints
- validerede fallback-oplysninger
- mulighed for at springe en opgave over med reduceret belønning
- parallelle spor, hvor det giver mening

---

# 7. Grundlæggende opgavetyper

## 7.1 Observation og optælling

Spilleren tæller en klart afgrænset type element.

### Designregel

Skriv præcist:

- hvad der tælles
- hvad der ikke tælles
- hvilket udsigtspunkt der gælder

### Godt eksempel

> Tæl de fem store, hvide bølgetoppe. Tæl ikke vinduer, altaner eller boliger.

### Dårligt eksempel

> Hvor mange bølger kan du se?

Ordet “bølger” kan betyde tagtoppe, facader, refleksioner eller vand.

### Egnet sværhedsgrad

Niveau 1–2 alene. Niveau 3, hvis resultatet kombineres med andre spor.

---

## 7.2 Matching

Spilleren matcher elementer på stedet med kort, symboler, årstal eller beskrivelser i appen.

Eksempel:

> Match tre statuer med de historiske personer, de repræsenterer.

### Designregel

Hver match skal kunne bevises ved en synlig detalje eller en oplysning i appen.

### Risiko

For mange muligheder skaber prøv-og-fejl i stedet for tænkning.

---

## 7.3 Mønstergenkendelse

Spilleren finder gentagelser, variationer eller en undtagelse.

Eksempel ved Spinderihallerne:

> Fire digitale vævemønstre vises. Kun ét følger rytmen i facadevinduerne.

### Designregel

Mønstret skal kunne udledes uden at gætte quizmasterens æstetiske fortolkning.

### God praksis

- marker, hvilket udsnit der undersøges
- brug samme orientering og målestok
- forklar, hvilke detaljer der ignoreres
- valider grafikken mod et foto

---

## 7.4 Sekvensering

Spilleren placerer objekter, begivenheder eller spor i korrekt rækkefølge.

Mulige rækkefølger:

- venstre mod højre
- ældst mod nyest
- opstrøms mod nedstrøms
- lavest mod højest
- rækkefølge på en rute

### Eksempel ved Vejle Å

Tre broer giver hver et symbol. Spilleren skal læse dem i åens strømretning.

### Designregel

Rækkefølgen skal enten være synlig, historisk nødvendig eller eksplicit kommunikeret.

Undgå en hemmelig rækkefølge, der kun giver mening for forfatteren.

---

## 7.5 Ekstraktion

Spilleren finder relevante bogstaver eller tal i en større mængde information.

Eksempler:

- første bogstav i tre navne
- markerede cifre i en inskription
- bogstaver på bestemte positioner
- årstal reduceret efter en synlig regel

### Designregel

Ekstraktionsreglen skal være cluet.

Hvis spilleren skal tage “tredje bogstav”, skal tallet tre komme fra opgaven eller fortællingen.

### Risiko

Vilkårlig ekstraktion føles som gætværk.

---

## 7.6 Substitution og symbolkode

Et sæt symboler oversættes gennem en tydelig nøgle.

Eksempel:

Et gammelt kort viser tre lokale symboler. En kodebog fra en tidligere opgave oversætter dem til bogstaver.

### Designregel

Nøglen skal være tilgængelig og entydig. Spilleren må ikke forventes at kende en historisk kode uden hjælp.

---

## 7.7 Rumlig og perspektivbaseret opgave

Spilleren skal stå et bestemt sted, orientere sig eller sammenholde elementer i synsfeltet.

Eksempel:

> Stå ved markeringen og se gennem åbningen. Hvilket monument indrammes?

### Designregel

Denne type kræver særlig præcis felttest:

- standpunkt
- højde
- synsretning
- spillernes forskellige kropshøjde
- vegetation
- menneskemængder
- sikkerhed

Den er visuelt stærk, men har høj QA-byrde.

---

## 7.8 Før og nu

Et historisk foto sammenlignes med nutiden.

Spilleren kan:

- finde hvad der stadig findes
- identificere et element, der er forsvundet
- placere fotoet i korrekt retning
- udlede ændringer i byens anvendelse

### Designregel

Referencefotoets standpunkt skal kunne genfindes. Perspektivet skal passe til opgaven.

### Rettigheder

Historiske billeder kræver dokumenteret brugsret eller licens.

---

## 7.9 Logisk deduktion

Spilleren kombinerer udsagn og eliminerer muligheder.

Eksempel:

> Tre historiske personer forbindes med tre steder. Synlige årstal og appens breve gør det muligt at finde den eneste korrekte kombination.

### Designregel

Alle nødvendige oplysninger skal være tilgængelige. Opgaven skal have én løsning.

God til niveau 3–5.

---

## 7.10 Transformation

Spilleren ændrer data efter en tydelig regel:

- roterer
- spejler
- folder mentalt
- læser baglæns
- flytter efter kompasretning
- konverterer symbol til tal

### Designregel

Transformationen skal antydes diegetisk.

Eksempel:

> Et spejl i fortællingen antyder, at teksten skal læses bagfra.

Undgå tilfældige transformationer uden clue.

---

## 7.11 Inventory-opgave

En tidligere fundet genstand fungerer som nøgle.

Eksempel:

- et kortfragment lægges over et nyt kort
- et segl identificerer korrekte symboler
- en kodebog oversætter runer
- et fotografi viser en manglende detalje

### Designregel

Genstanden skal have et klart formål og kunne genåbnes i appen.

### Risiko

Hvis spilleren ikke har genstanden, kan opgaven blokere. Systemet skal håndtere afhængigheden tydeligt.

---

## 7.12 Flerlokationsopgave

Spilleren indsamler data flere steder.

Eksempel:

Tre broer giver cifrene til en afsluttende kode.

### Styrke

Skaber bevægelse og større fortælling.

### Risiko

- høj tidsbelastning
- én utilgængelig lokation kan blokere alt
- spilleren kan glemme mellemresultater

Brug inventory eller automatisk notering.

---

## 7.13 Meta-puzzle

En meta-puzzle bruger resultater fra flere færdige opgaver.

### Eksempel

Fem opgaver i Vejle giver:

- bølge
- nøgle
- vand
- tråd
- krone

Finalen viser en historisk tekst, hvor symbolerne bestemmer hvilke ord, der skal udvælges.

### Designregel

Meta-puzzlen må ikke kræve, at spilleren gætter, hvilke tidligere resultater der er relevante.

Alle komponenter skal:

- være navngivet
- være tilgængelige i inventory
- have en ensartet visuel form
- være testet både enkeltvis og samlet

---

# 8. Fairness

En fair puzzle kan være svær, men spilleren kan bagefter sige:

> “Det kunne jeg godt have fundet ud af.”

## 8.1 Alle nødvendige oplysninger er tilgængelige

Spilleren skal ikke:

- google noget uanmeldt
- have specialviden
- kende quizmasterens intention
- gætte et usynligt mellemtrin

## 8.2 Clueability

Hver nødvendig handling skal være cluet.

Hvis spilleren skal:

- tælle → angiv hvad der tælles
- sortere → angiv eller clue rækkefølgen
- spejle → giv et spejlmotiv
- bruge tredje bogstav → giv tallet tre
- gå mod nord → giv kompas eller retning

## 8.3 Ét semantisk spring ad gangen

Et semantisk spring er et skift i fortolkning.

Eksempel:

> Bølgeformer bliver til tal.

Det kan være fair, hvis mappingen vises.

Tre skjulte fortolkningsspring i samme trin skaber ofte gætteri.

## 8.4 Ingen moon logic

“Moon logic” er løsninger, der kun giver mening for designeren.

Eksempel:

> Tag antallet af vinduer, træk arkitektens initialer fra og læs resultatet baglæns, fordi bygningen står ved vand.

Dette er ikke en gåde; det er vilkårlig manipulation.

## 8.5 Brute force må ikke være den bedste strategi

Hvis spilleren kan prøve alle 1000 koder hurtigere end at løse opgaven, bør appen:

- begrænse hurtige forsøg
- give intelligent feedback
- bruge flere svarfelter
- gøre delresultater synlige
- anvende valg eller rækkefølge i stedet for fri kode

Formålet er ikke straf, men at bevare puzzle-oplevelsen.

---

# 9. Misdirection og distraktorer

Misdirection er legitim, når den skaber et kort øjeblik af tvivl, men stadig kan gennemskues ud fra sporene.

## 9.1 God misdirection

- en plausibel, men forkert silhuet
- et ekstra tal, som tydeligt ikke passer til reglen
- en historisk person fra forkert periode
- et symbol, der mangler en afgørende detalje

## 9.2 Dårlig misdirection

- elementer, der kun er forkerte med mikroskopiske forskelle
- information uden nogen funktion
- vildledende formulering
- et falsk spor, der er lige så logisk som det rigtige
- bevidst udeladelse af den nødvendige regel

## 9.3 Distraktorer skal være falsificerbare

Spilleren skal kunne forklare, hvorfor en mulighed er forkert.

Eksempel:

> Silhuet D er forkert, fordi den kombinerer toppen fra én åbning med bunden fra en anden.

Dette er bedre end:

> Silhuet D “ser ikke rigtig ud”.

---

# 10. Kodegenerering

Koder giver escape room-stemning, men de må ikke være dekorative.

## 10.1 Synlig mapping

Vis hvordan et delresultat bliver til et ciffer eller bogstav.

Eksempel:

| Symbol | Betydning | Resultat |
|---|---|---:|
| Øjet | Antal bølger | 5 |
| Etager | Etager pr. bølge | 9 |
| Pausen | Første færdige bølger | 2 |

## 10.2 Entydig rækkefølge

Rækkefølgen kan gives gennem:

- tekst
- symbolrækkefølge
- geografisk rækkefølge
- tidslinje
- venstre mod højre
- opstrøms mod nedstrøms
- tidligere inventory

Skriv ikke blot:

> “Sæt tallene sammen.”

## 10.3 Koden skal have en narrativ funktion

Koden kan åbne:

- et brev
- en dagbog
- et arkiv
- et kort
- et digitalt skrin
- et nyt kapitel

Koden bør ikke være en løs teknisk kontrol uden betydning.

## 10.4 Undgå for lange koder

For målgruppen er 3–5 tegn normalt passende.

Længere koder bør opdeles i deltrin eller visuelle komponenter.

---

# 11. Hint-design

Hints er ikke en straf. De er en del af designet.

En opgave er ikke færdig, før dens hintstige er designet og testet.

## 11.1 Diagnostisk tænkning

Et godt hint adresserer den sandsynlige misforståelse.

Spørg:

- Har spilleren ikke fundet sporet?
- Har spilleren fundet sporet, men ikke reglen?
- Har spilleren reglen, men forkert rækkefølge?
- Har spilleren de rigtige delresultater, men laver en regnefejl?

## 11.2 Tretrinsmodellen

### Hint 1 – hvor

Peg på det relevante område eller type spor.

> “Se på de store hvide hovedformer – ikke på altanerne.”

### Hint 2 – hvordan

Forklar metode eller rækkefølge.

> “Koden følger Øjet → Etagerne → Pausen.”

### Hint 3 – hvad

Giv mellemresultaterne, men lad spilleren udføre sidste handling.

> “Du skal bruge 5, 9 og 2 i den viste rækkefølge.”

## 11.3 Dårlige hints

- “Tænk dig om”
- “Se godt efter”
- “Det har noget med historien at gøre”
- “Svaret er næsten foran dig”

Disse hjælper ikke en fastlåst spiller.

## 11.4 Hintfradrag

Byens Hemmeligheders standard:

- Hint 1: -3 %
- Hint 2: yderligere -4 %
- Hint 3: yderligere -5 %

En spiller med alle hints modtager stadig 88 % af pointene.

---

# 12. Sværhedsgrad

Sværhedsgrad bør vurderes på kognitive forhold, ikke fysisk besvær.

## 12.1 Faktorer

- antal nødvendige spor
- antal mentale trin
- hvor tydelig reglen er
- antal plausible forkerte svar
- krav til arbejdshukommelse
- behov for tidligere inventory
- antal lokationer
- abstraktionsniveau
- mængde tekst
- nødvendigt samarbejde

## 12.2 Niveauer

| Niveau | Karakter | Typisk design |
|---|---|---|
| 1 | Introduktion | én tydelig observation |
| 2 | Let | observation + enkel regel |
| 3 | Standard | 2–3 spor + kombination/kode |
| 4 | Svær | flere trin, inventory eller deduktion |
| 5 | Ekspert | flerlags- eller meta-puzzle |

## 12.3 Sværhedsgrad må ikke skabes gennem

- dårlig kontrast
- mikroskopisk tekst
- farlig adgang
- manglende oplysninger
- upræcist sprog
- uventet specialviden
- bevidst tvetydighed

Det er fejl, ikke sværhedsgrad.

---

# 13. Samarbejde for familier

Appen starter uden en formel holdkonto, men opgaver kan stadig designes til samarbejde.

## 13.1 Naturlige roller

- observatøren finder fysiske spor
- læseren fortolker historien
- logikeren kombinerer information
- kontrolløren tjekker rækkefølgen
- den yngste opdager visuelle detaljer

## 13.2 Informationsfordeling

Samarbejde kan opstå ved:

- spor i forskellige retninger
- én skærm med tekst og én fysisk observation
- flere små delopgaver
- en fælles beslutning før svar
- inventory fra tidligere steder

## 13.3 Undgå quarterbacking

“Quarterbacking” opstår, når én erfaren voksen løser alt.

Modvirk det ved at:

- skrive korte instruktioner
- give børn observationer, der er reelt nødvendige
- dele opgaven i parallelle delspor
- bruge visuelle elementer
- bede familien sammenligne deres fund

---

# 14. Narrativ integration

## 14.1 Historien skal begrunde mekanikken

Eksempler:

- arkitektens note → form og mål
- væverens mønster → gentagelse og sekvens
- brovagtens adgangskode → symboler og rækkefølge
- arkivarens manglende side → ekstraktion
- sømandens kompas → retning

## 14.2 Fakta og fiktion

Brug en tydelig markering:

> **Fiktiv mission baseret på stedets dokumenterede historie.**

Fiktive breve, dagbøger og karakterer må ikke fremstilles som ægte arkivfund.

## 14.3 Kort mobiltekst

En opgaveintro bør ofte kunne læses på 20–40 sekunder.

Brug:

- korte afsnit
- ét formål
- tydeligt mysterium
- handlingsverbum
- fremhævede nøgleord

## 14.4 Opgavens rolle i helheden

Angiv om opgaven er:

- introduktion
- træning i en mekanik
- eskalering
- afsløring
- vendepunkt
- finale
- sideopgave

Opgaven bør bidrage med:

- information
- symbol
- inventory
- relation mellem personer
- retning
- kodefragment
- ny mistanke
- adgang til næste kapitel

---

# 15. Tilgængelighed og kognitiv klarhed

## 15.1 Sprog

- korte sætninger
- konkret ordvalg
- ét hovedbudskab pr. skærm
- forklar ukendte historiske ord
- undgå unødvendig teknisk terminologi

## 15.2 Visuelt design

- høj kontrast
- store trykflader
- tydelige labels
- undgå at kode alene med farver
- mulighed for tekstforstørrelse
- referencefoto med tydelig markering

## 15.3 Kognitiv belastning

Appen bør automatisk gemme:

- delresultater
- fundne symboler
- inventory
- tidligere hints
- vigtige historiske oplysninger

Spilleren skal ikke huske en lang kode under en gåtur.

## 15.4 Fysisk tilgængelighed

Registrér:

- underlag
- stigning
- trapper
- afstand
- siddemulighed
- kørestolsadgang
- lydmiljø
- mørke
- åbningstider

En rute kan tilbyde alternative opgaver eller tydelig mærkning, hvis alle steder ikke er tilgængelige.

---

# 16. Sikkerhed og tilladelser

## 16.1 Opgaven må ikke kræve

- adgang til privat område
- klatring
- berøring af fredede eller sårbare objekter
- færdsel på vej, bane eller farligt havneareal
- at spilleren står tæt på vandkant eller skrænt
- at spilleren ser på telefonen under krydsning
- forstyrrelse af beboere eller aktiviteter
- flytning af ting, der ikke tilhører spillet

## 16.2 Sikkert standpunkt

Registrér:

- koordinat
- foto
- synsretning
- sikker ståflade
- afstand til trafik/vand
- plads til en familie
- GPS-radius

## 16.3 Fysiske installationer

QR-koder, NFC-tags, skilte eller cacher kræver ofte tilladelse og vedligehold.

MVP bør som udgangspunkt være **digital-only**, hvor stedet selv er rekvisitten.

---

# 17. Medierettigheder og persondata

Quizmasteren skal registrere:

- fotograf
- ejer
- licens
- kreditering
- tilladt anvendelse
- eventuel udløbsdato
- om identificerbare personer optræder

Undgå identificerbare personer på referencefotos, medmindre behandlingsgrundlag og brugsret er afklaret.

AI-genererede illustrationer skal markeres internt som AI-genererede og må ikke bruges som dokumentation for, hvordan stedet faktisk ser ud.

---

# 18. AI'ens rolle

AI er stærk til:

- researchoverblik
- variation af koncepter
- historiefortælling
- hints
- distraktorer
- UX-tekst
- løsningsbevis
- konsistenstjek
- JSON/Markdown
- testcases

AI er svagere til:

- at vide præcis hvad der kan ses fra stedet
- geometrisk korrekte silhuetter
- aktuelle adgangsforhold
- sikkerhed
- GPS-radius
- tilladelser
- billedrettigheder
- forståelse af, hvor målgruppen reelt går i stå

Derfor:

> AI kan gøre opgaven logisk og redaktionelt stærk. Quizmasteren skal gøre den fysisk sand.

---

# 19. Designworkflow

## Trin 1 – Sted og intention

Definér:

- hvorfor stedet er interessant
- hvilken oplevelse spilleren skal have
- hvilken rolle opgaven har i historien

## Trin 2 – Researchpakke

Indsaml:

- officielle kilder
- historiske fakta
- billeder
- kort
- mulige stabile fysiske spor

## Trin 3 – Feltpakke

Indsaml:

- præcist standpunkt
- GPS
- referencefotos
- nærbilleder
- video/panorama
- sikkerhed og adgang

## Trin 4 – Tre koncepter

Lav:

1. et robust, enkelt koncept
2. et narrativt koncept
3. et mere escape room-præget koncept

Vælg efter kvalitet, ikke kompleksitet.

## Trin 5 – Paper solve

Skriv:

- alle spillerdata
- alle mellemtrin
- facit
- hvorfor alternativer er forkerte

Løs opgaven uden forfatterens forklaring.

## Trin 6 – Hintstige

Design hints til de tre mest sandsynlige fastlåsninger.

## Trin 7 – Adversarial review

Prøv aktivt at ødelægge opgaven:

- find alternative svar
- find skjulte antagelser
- find ustabile spor
- find uklare rækkefølger
- find brute force-muligheder

## Trin 8 – Felttest

Gennemfør opgaven på stedet uden ekstra forklaring.

## Trin 9 – Målgruppetest

Test med børn/unge og familier.

## Trin 10 – Revision og publiceringsport

Publicér først, når alle åbne punkter er lukket.

---

# 20. Playtesting

## 20.1 Observer – forklar ikke

Quizmasteren bør ikke hjælpe under første test, medmindre sikkerheden kræver det.

Notér:

- hvad spillerne kigger på
- hvad de tror skal tælles
- hvor de går i stå
- hvilke regler de opfinder
- om de bruger telefonen for meget
- om hints virker
- hvor lang tid det tager

## 20.2 Think-aloud

Bed enkelte testspillere sige højt, hvad de tænker.

Det afslører:

- tvetydige ord
- manglende clues
- forkert mental model
- skjulte mellemtrin

## 20.3 Test facit og ikke kun succes

At en gruppe finder svaret betyder ikke nødvendigvis, at opgaven er god. De kan have:

- gættet
- brute-forcet
- fået hjælp
- brugt ekstern viden
- forstået en anden regel end den tilsigtede

Spørg efter løsning:

> “Hvordan kom I frem til svaret?”

## 20.4 Test alle hints

Start nye testpersoner ved hvert hintniveau.

Et hint skal føre til den korrekte løsningsmetode, ikke kun facit.

## 20.5 Test vejr og tid

Hvor relevant:

- sol
- overskyet
- regn
- vinter
- sommer
- travlt tidspunkt
- stille tidspunkt

---

# 21. Typiske fejl

## 21.1 Facit er valgt før sporene

Designeren vil have koden `428` og forsøger bagefter at finde tre tal, der passer.

**Løsning:** Lad verificerede spor bestemme facit.

## 21.2 Uklart optællingsobjekt

“Antal vinduer” eller “antal buer” kan fortolkes på flere niveauer.

**Løsning:** Marker visuelt og beskriv afgrænsningen.

## 21.3 Historien indeholder irrelevant tekst

Spilleren læser meget, men teksten hjælper ikke gåden.

**Løsning:** Hver tekstblok skal have funktion.

## 21.4 Reglen er kun kendt af quizmasteren

“Selvfølgelig læser man venstre mod højre.”

**Løsning:** Gør rækkefølgen synlig eller clue den.

## 21.5 AI-visualisering behandles som virkelighed

En AI-genereret facade eller silhuet bliver brugt som facitgrundlag.

**Løsning:** Brug foto og menneskelig annotering.

## 21.6 Opgaven testes kun af forfatteren

Forfatteren kan ikke opdage alle egne antagelser.

**Løsning:** Uafhængig solve-test og målgruppetest.

## 21.7 Sværhedsgrad skabes gennem frustration

Små detaljer, meget tekst eller upræcis GPS bruges til at gøre opgaven “svær”.

**Løsning:** Skab sværhed gennem logik og kombination.

## 21.8 Hints afslører forkert ting

Hintet gentager introen, mens spilleren mangler rækkefølgen.

**Løsning:** Diagnosticér fastlåsningen.

## 21.9 For mange mekanikker i én opgave

Spilleren skal tælle, dekryptere, regne, gå, matche og huske på én gang.

**Løsning:** Én primær mekanik og højst én supplerende på niveau 2–3.

## 21.10 Flot mockup skjuler logisk hul

UI ser færdigt ud, men facit kan ikke udledes.

**Løsning:** Mockups kommer efter løsningsbevis og konsistenstjek.

---

# 22. Kvalitetsrubrik

Bedøm 1–5.

| Kriterium | 1 | 5 |
|---|---|---|
| Lokationsrelevans | Kun GPS-checkpoint | Kan kun løses netop her |
| Stedets stabilitet | Midlertidigt/usikkert | Permanent og robust |
| Historisk kvalitet | Uklar/opdigtet | Præcis og kildebaseret |
| Narrativ integration | Pynt | Fortællingen driver mekanikken |
| Clueability | Skjulte regler | Alle handlinger er cluet |
| Entydighed | Flere plausible svar | Ét dokumenteret facit |
| Underholdning | Turistquiz | Tydeligt aha og progression |
| Familiesamarbejde | Én person løser | Flere naturlige roller |
| Sværheds-match | Fejlkalibreret | Passer klart til niveau |
| Hint-kvalitet | Vage/afslørende | Diagnostiske og progressive |
| Sikkerhed | Risikabelt | Sikkert offentligt standpunkt |
| Tilgængelighed | Ikke beskrevet | Tydelig og realistisk |
| Helårsrobusthed | Sæsonafhængig | Fungerer stabilt |
| UX-egnethed | Teksttung/uklar | Kort og mobilvenlig |
| Helhed | Isoleret | Bidrager til større historie |

Minimum før publicering:

- Entydighed: 5
- Sikkerhed: 5
- Clueability: mindst 4
- Lokationsrelevans: mindst 3
- Stedets stabilitet: mindst 4
- Hint-kvalitet: mindst 4

---

# 23. Eksempler til Byens Hemmeligheder

## 23.1 Bølgen – Den femte besked

**Mekanik:** Observation + faktatekst + kode  
**Sværhedsgrad:** 3  
**Verificerede delresultater:**

- fem bølger
- ni etager pr. bølge
- to første bølger før byggepausen

**Rækkefølge:** Øjet → Etagerne → Pausen  
**Facit:** `592`

Hvorfor den virker:

- stedet leverer det første tal
- fortællingen giver rækkefølge
- appen leverer dokumenterede fakta
- facit kan bevises
- børn og voksne kan bidrage forskelligt

---

## 23.2 Fjordenhus – Vandets tromler

**Mekanik:** Observation + kildebaserede fakta + kode  
**Sværhedsgrad:** 3  

Muligt verificeret grundlag:

- fire sammenhængende hovedcylindre
- to rum i stueetagen gennemstrømmes af vand
- højden er 28 meter, hvor sidste ciffer er 8

**Rækkefølge:** Form → Vand → Højde  
**Facit:** `428`

Quizmasterkrav:

- verificér at “fire hovedcylindre” kan forstås fra standpunktet
- appens tekst skal levere de ikke-observerbare fakta
- instruktionen skal sige, at åbninger og vinduer ignoreres

---

## 23.3 Spinderihallerne – Væverens rytme

**Mekanik:** Mønstergenkendelse  
**Sværhedsgrad:** 2–3  

Koncept:

- Spilleren ser tre korte digitale vævemønstre.
- Ét mønster følger en valideret rytme i en bestemt vinduesrække.
- Det korrekte mønster giver et symbol til inventory.

Quizmasterkrav:

- vælg og fotografer præcis vinduesrække
- annotér gentagelsen
- kontrollér at mønstret er synligt året rundt
- falske mønstre skal være plausible, men klart afviselige

---

## 23.4 Vejle Å – Broernes rækkefølge

**Mekanik:** Flerlokation + sekvensering  
**Sværhedsgrad:** 3–4  

Koncept:

- Tre broer giver hvert et symbol.
- Appen fortæller, at beskeden skal læses med vandets retning.
- Symbolerne sættes i rækkefølge opstrøms → nedstrøms.

Styrke:

- den fysiske geografi er selve reglen

Quizmasterkrav:

- verificér strømretning
- sikre ruter mellem punkterne
- undgå trafikfarlige standpunkter
- automatisk gemme hvert symbol

---

## 23.5 Skyttehushaven – Udsigten gennem tiden

**Mekanik:** Før og nu  
**Sværhedsgrad:** 2  

Koncept:

- Et historisk billede vises.
- Spilleren finder det korrekte standpunkt.
- Tre markerede nutidige elementer sammenlignes.
- Ét element fandtes ikke i den historiske periode.

Quizmasterkrav:

- billedrettigheder
- præcist standpunkt
- stabilt udsyn
- historisk faktakontrol
- undgå, at vegetation gør opgaven sæsonafhængig

---

## 23.6 Ravningbroen – Kongens passage

**Mekanik:** Historisk deduktion + inventory  
**Sværhedsgrad:** 4  

Koncept:

- Spilleren har tidligere fundet et digitalt kongesegl.
- Appen viser tre mulige transportbeskeder.
- Broens dokumenterede funktion og seglets symbol udpeger den eneste gyldige.

Designregel:

- historiske fakta skal være i appen eller synlige på stedet
- ingen forventning om forhåndsviden

---

## 23.7 Egtvedpigen – Rejsens spor

**Mekanik:** Flertrinsdeduktion  
**Sværhedsgrad:** 4–5  

Koncept:

- Tre korte kildestykker handler om gravfund, beklædning og rejse.
- Spilleren matcher dem med tre symboler.
- Symbolernes rækkefølge giver et kodeord.

Risiko:

- for meget tekst
- komplekse eller omdiskuterede historiske fortolkninger

Løsning:

- brug museumsgodkendte formuleringer
- del opgaven i små skærme
- markér usikker historisk viden som usikker

---

# 24. Quizmasterens checkliste

## Før design

- [ ] Stedet har en interessant fortælling.
- [ ] Der findes mindst ét stabilt fysisk spor.
- [ ] Stedet er offentligt og sikkert.
- [ ] Opgavens rolle i en større historie er kendt.

## Før felttest

- [ ] Facit bestemmes af sporene – ikke omvendt.
- [ ] Alle nødvendige handlinger er cluet.
- [ ] Løsningsbeviset er skrevet.
- [ ] Alternative plausible svar er undersøgt.
- [ ] Tre hints er skrevet.
- [ ] Forkert-svar-feedback er skrevet.
- [ ] Standpunkt og billeder er dokumenteret.
- [ ] Fakta og fiktion er adskilt.
- [ ] Medierettigheder er registreret.

## Før publicering

- [ ] Opgaven er fysisk gennemført af andre.
- [ ] Målgruppen har testet den.
- [ ] Spillerne kan forklare løsningen korrekt.
- [ ] Hints er testet.
- [ ] Sikkerhed og tilgængelighed er godkendt.
- [ ] GPS-radius er testet.
- [ ] Alle UI-skærme bruger samme facit.
- [ ] Opgaven er versioneret.
- [ ] Seneste fysiske kontrol er registreret.
- [ ] Redaktør har godkendt.

---

# 25. Bindende regler til Custom GPT'en

Følgende regler skal anvendes af GPT'en, hver gang den designer eller vurderer en opgave:

1. Identificér opgavens **signal, spor, regel, handling, facit og feedback**.
2. Beskriv den fulde puzzle-loop: **opdag → forstå → bearbejd → bekræft → beløn**.
3. Angiv den primære puzzle-mekanik og højst én supplerende mekanik for niveau 1–3.
4. Brug observerbare invariants som facitgrundlag.
5. Kræv præcist standpunkt og referencefoto til visuelle opgaver.
6. Vis clue-to-answer-sporbarhed for hvert mellemresultat.
7. Tillad højst ét ukluet semantisk spring; ideelt nul.
8. Skeln mellem reel sværhedsgrad og fejlskabt frustration.
9. Forklar kodens mapping og rækkefølge eksplicit eller gennem et testbart clue.
10. Design distraktorer, der er plausible, men objektivt falsificerbare.
11. Design hints som **hvor → hvordan → hvad**.
12. Test for brute force, alternative svar og skjulte antagelser.
13. Undgå single-point-of-failure i længere ruter.
14. Beskriv opgavens rolle i den større historie og dens konkrete belønning.
15. Sørg for, at inventory har en senere funktion.
16. Gennemfør et konsistenstjek af alle tal, navne, symboler og facitter.
17. Lav ikke iOS-mockups før løsningsbeviset er godkendt.
18. Kald aldrig en opgave publiceringsklar uden menneskelig felttest.
19. Hvis steddata er utilstrækkelige, skal GPT'en stoppe og beskrive manglerne.
20. En enklere, vandtæt opgave skal altid foretrækkes frem for en spektakulær, tvetydig opgave.

---

# 26. Kilder og videre læsning

Retningslinjerne er udarbejdet med inspiration fra research om escape rooms, educational escape games, puzzle- og narrativt design, brugertest, tilgængelighed og outdoor location-based experiences.

Centrale kilder:

- Scott Nicholson: *Peeking Behind the Locked Door – A Survey of Escape Room Facilities*  
  https://docslib.org/doc/9862714/peeking-behind-the-locked-door-a-survey-of-escape-room-facilities

- Heidi Eukel & Bryan Morrell: Escape room design og iterativ udvikling  
  https://journals.sagepub.com/doi/10.1177/1046878120953453

- Room2Educ8 / educational escape-room frameworks  
  https://www.mdpi.com/2227-7102/12/11/768

- Escape room design framework og puzzle-struktur  
  https://www.mdpi.com/2227-7102/16/3/375

- W3C – inddragelse af brugere og kognitiv tilgængelighed  
  https://www.w3.org/WAI/planning/involving-users/  
  https://www.w3.org/WAI/cognitive/

- Digitaliseringsstyrelsen – webtilgængelighed  
  https://digst.dk/tilsyn/webtilgaengelighed/

- Geocaching – officielle placerings- og sikkerhedsretningslinjer  
  https://www.geocaching.com/play/guidelines

- Vejle Kommune – tilladelser til offentlige arealer  
  https://www.vejle.dk/da/service-og-selvbetjening/erhverv/erhvervsbyggeri-og-grunde/tilladelser-til-bygge-og-anlaegsarbejde/

- Datatilsynet – billeder og personoplysninger  
  https://www.datatilsynet.dk/regler-og-vejledning/

Lokale referencekilder:

- Bølgen, VisitVejle  
  https://www.visitvejle.dk/vejle/planlaeg-ferien/boelgen-gdk724987

- Bølgen, Henning Larsen  
  https://www.henninglarsen.com/projects/the-wave-in-vejle

- Fjordenhus  
  https://www.fjordenhus.dk/dk/fjordenhus/

- Fjordenhus, VisitVejle  
  https://www.visitvejle.dk/vejle/planlaeg-ferien/fjordenhus-gdk1101859

---

# 27. Afsluttende princip

Byens Hemmeligheder skal skabe oplevelsen af, at byen selv gemmer på gåden.

Det opnås ikke gennem flest mulige koder eller mest mulig tekst. Det opnås gennem en præcis forbindelse mellem:

- det spilleren ser
- det historien får spilleren til at forstå
- den handling spilleren udfører
- det facit, der kan bevises
- den afsløring, der følger

> **Den bedste opgave føles overraskende før løsningen og indlysende bagefter.**
