# Gold-standard eksempel: Bølgen – Den femte besked

## Formål med eksemplet

Dette er et eksempel på, hvordan en opgave kan have et fuldt dokumenteret facit og samtidig bevare en escape room-agtig stemning.

Eksemplet er **felttestklart**, ikke automatisk publiceringsklart. Et menneske skal stadig vælge og kontrollere det præcise spillerstandpunkt, sikkerhed, GPS-radius og billeder.

---

# Bølgen – Den femte besked

**Status:** Felttestklar  
**Sværhedsgrad:** 3  
**Type:** Observation, historie og kode  
**Målgruppe:** 10–15 år og familie  
**Varighed:** 8–12 minutter  
**Facit:** `592`  
**Grundpoint:** 100  
**Inventory-belønning:** Det femte signal  


## Kilder

- VisitVejle – Bølgen: https://www.visitvejle.dk/vejle/planlaeg-ferien/boelgen-gdk724987
- Henning Larsen – The Wave in Vejle: https://www.henninglarsen.com/projects/the-wave-in-vejle

Kilderne skal genkontrolleres ved senere redaktion, hvis de anvendes i en publiceret opgave.

---

## Dokumenterede fakta

Officielle kilder beskriver:

- Bølgen består af fem bølger.
- Hver bølge har ni etager.
- De to første bølger stod færdige i 2009.
- De sidste tre blev senere opført, og alle fem stod færdige i 2018.

Disse tre entydige tal anvendes som facitdata:

`5 – 9 – 2`

## Fiktiv ramme

> En glemt arkitektbesked kunne først åbnes, når alle fem bølger stod færdige.

Vis teksten:

> **Fiktiv mission baseret på Bølgens dokumenterede bygge- og arkitekturhistorie.**

## Narrativ intro

> I 2009 stod kun begyndelsen af Bølgen færdig. En glemt besked fortæller, at den først kan åbnes, når alle bølger er rejst ved fjorden.
>
> Tre symboler viser vejen:
>
> **Øjet → Etagerne → Pausen**

## Spor 1 – Øjet

> Se på hele byggeriet. Hvor mange store, hvide bølgetoppe kan du se?
>
> Tæl toppene – ikke vinduer, altaner eller boliger.

Svar: `5`

## Spor 2 – Etagerne

Appen giver den verificerede oplysning:

> Hver bølge består af ni etager.

Svar: `9`

Spilleren skal ikke google oplysningen. Den gives som en del af missionens historiske materiale.

## Spor 3 – Pausen

> Hvor mange bølger stod færdige, før byggeriet gik i stå?

Svar: `2`

## Kode

Symbolrækkefølgen er eksplicit:

1. Øjet = 5
2. Etagerne = 9
3. Pausen = 2

**Kode: `592`**

## Facit og løsningsbevis

1. Spilleren tæller fem bølgetoppe ved stedet.
2. Appens kildebaserede notat angiver ni etager pr. bølge.
3. Appens historiske tekst angiver, at to bølger stod færdige før pausen.
4. Introen viser rækkefølgen Øjet → Etagerne → Pausen.
5. Tallene sættes derfor sammen som `5`, `9`, `2`.
6. Det eneste gyldige facit er `592`.

## Hints

### Hint 1 – lille skub

> Det første tal findes ved at se på hele byggeriet. Tæl de store hvide toppe.

### Hint 2 – konkret hjælp

> Koden følger rækkefølgen: antal bølger i dag → etager i hver bølge → bølger før byggepausen.

### Hint 3 – næsten løsningen

> Du skal bruge fem bølger, ni etager og to bølger før pausen. Sæt tallene i den viste rækkefølge.

## Typisk forkert svar: 529

Feedback:

> Du har de rigtige tal, men rækkefølgen er forkert. Følg symbolerne fra venstre mod højre: Øjet → Etagerne → Pausen.

## Succesbesked

> Fem toppe rejser sig ved fjorden. De spejler bakkerne omkring Vejle og fortæller om byen mellem landskab og hav.
>
> Du har fundet **Det femte signal**.

## Hvad mennesket skal gøre

- besøge stedet
- vælge et sikkert offentligt standpunkt
- sikre, at alle fem toppe kan ses
- tage eller licensere et referencefoto
- registrere GPS og radius
- kontrollere, at børn forstår, hvad der skal tælles
- teste alle hints
- kontrollere, at den fiktive ramme ikke forveksles med en ægte arkivkilde
- godkende kilder og formulering
