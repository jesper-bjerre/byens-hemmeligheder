# Opsætning af Custom GPT

## Foreslået navn

**Byens Hemmeligheder – Quizmaster**

## Kort beskrivelse

Hjælper frivillige quizmastere med at finde steder, researchere lokalhistorie og udvikle komplette, sikre og stedsspecifikke escape room-opgaver til Byens Hemmeligheder.

## Samtalestartere

1. **Jeg har fundet et sted i Vejle. Vurder om det egner sig til en opgave, og fortæl hvilke data du mangler.**
2. **Her er billeder og kilder til et sted. Lav tre forskellige opgavekoncepter og anbefal det stærkeste.**
3. **Kvalitetstjek denne opgave. Find tvetydige spor, ugyldige antagelser og problemer med facit eller hints.**
4. **Lav en felttestklar opgave på sværhedsgrad 3, der passer ind i historien [navn].**
5. **Lav et præcist iOS-skærmflow til denne validerede opgave. Brug samme facit på alle skærme.**
6. **Hjælp mig med at lave en research- og feltpakke for [sted].**

## Filer, der uploades som viden

Upload disse filer i rækkefølge:

1. `01_Byens_Hemmeligheder_Endeligt_Projektgrundlag.md`
2. `07_Retningslinjer_Escape_Room_Opgavedesign.md`
3. `03_Quizmastermanual.md`
4. `04_Opgaveskabelon.md`
5. `05_Gold_Standard_Boelgen.md`

Filen med GPT-instruktioner skal kopieres ind i feltet **Instructions** og bør ikke kun uploades som viden.

## Capabilities

Aktivér:

- **Web Search** – nødvendig til kildebaseret research og aktuelle adgangsforhold.
- **Image Generation** – til illustrationer og fiktive iOS-mockups efter logisk validering.
- **Code Interpreter & Data Analysis** – nyttig til strukturerede data, kortlister, billedanalyse, JSON og konsistenstjek.

Start uden Apps og Actions. En senere version kan få en Action til quizmasterportalen, når dens API findes.

## Deling

Begynd som:

- privat GPT eller
- delt via link til en lille gruppe quizmastere

Udgiv ikke offentligt, før instruktioner og output er testet med flere lokationer.

## Test i Preview

Kør mindst disse tests:

### Test 1 – For få data

Prompt:

> Lav en færdig opgave til en gammel bro i Vejle.

Forventning:

- GPT'en må ikke opfinde bro, koordinater eller facit.
- Den skal angive status og efterspørge konkrete data.

### Test 2 – Tvetydig visuel opgave

Prompt:

> Lav en kode ud fra formerne i denne facade.

Upload ét upræcist foto.

Forventning:

- GPT'en skal kræve standpunkt og visuel validering.
- Den må ikke opfinde silhuetter eller kode.

### Test 3 – Gyldig datadrevet opgave

Prompt:

> Brug Bølgen-eksemplet og forklar facit trin for trin.

Forventning:

- Facit skal være 592.
- Løsningsbevis, hints og UX skal være konsistente.

### Test 4 – Review

Prompt:

> Find alle fejl i denne opgave og vær kritisk.

Forventning:

- GPT'en skal prioritere entydighed, fysisk realisme og sikkerhed over høflighed.

### Test 5 – Screenshots

Prompt:

> Lav iOS-mockups.

Forventning:

- GPT'en skal først kontrollere, om opgaven har passeret publiceringsporten eller mindst er logisk felttestklar.
- Alle mockups skal vise samme facit.

### Test 6 – Puzzle-anatomi

Prompt:

> Design en opgave ved et monument, men vis først signal, spor, regel, handling, facit og feedback.

Forventning:

- GPT'en skal udfylde alle seks dele.
- Hvis fysisk data mangler, skal facit stå åbent.

### Test 7 – Moon logic

Prompt:

> Brug antal vinduer, arkitektens initialer og en spejling til at skabe en kode.

Forventning:

- GPT'en skal afvise en vilkårlig kombination uden clues.
- Den skal foreslå en enklere og fair mekanik.

### Test 8 – Hintdiagnose

Prompt:

> Spilleren har fundet alle tre tal, men sætter dem i forkert rækkefølge. Lav et hint.

Forventning:

- Hintet skal adressere rækkefølgen og ikke blot sige “se godt efter”.

## Vedligeholdelse

Når projektets regler ændres:

1. Opdatér det autoritative projektgrundlag.
2. Opdatér GPT-instruktionerne, hvis adfærd eller workflow ændres.
3. Gem en ny GPT-version.
4. Genkør preview-testene.
5. Notér ændringen i GPT'ens interne versionslog.

## Oprettelse i ChatGPT

På ChatGPT-web:

1. Åbn GPT-området.
2. Vælg **Create**.
3. Åbn konfigurationsvisningen.
4. Indsæt navn og beskrivelse.
5. Indsæt hele `02_Custom_GPT_Instructions.md` i **Instructions**.
6. Tilføj samtalestarterne.
7. Upload vidensfilerne.
8. Aktivér de anbefalede capabilities.
9. Test i Preview.
10. Gem og vælg den ønskede delingsform.

Officiel vejledning:

- https://help.openai.com/da-dk/articles/8554397-creating-and-editing-gpts
- https://help.openai.com/en/articles/8554407-creating-a-gpt
