# Versionslog – Custom GPT-pakken

## Version 2.0

Opdateret med grundig research om escape room- og puzzle design.

### Tilføjet

- `07_Retningslinjer_Escape_Room_Opgavedesign.md`
- puzzle-anatomi: signal, spor, regel, handling, facit og feedback
- puzzle-loop: opdag, forstå, bearbejd, bekræft og beløn
- regler for clueability, fairness og moon logic
- observerbare invariants til outdoor-opgaver
- puzzle-arkitektur: lineær, parallel, forgrenet og meta
- teknikbibliotek
- bindende regler for kodegenerering og hints
- playtest- og kvalitetsrubrik
- flere Vejle-eksempler

### Opdateret

- GPT-instruktionerne bruger metodeguiden normativt.
- Opsætningsvejledningen uploader den nye vidensfil.
- Preview-tests kontrollerer puzzle-anatomi, moon logic og hintdiagnose.
- Builder-prompten henviser til retningslinjerne.
