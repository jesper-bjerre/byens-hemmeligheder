# Byens Hemmeligheder – Quizmastermanual

## Formål

Denne fil er referenceviden til Custom GPT'en **Byens Hemmeligheder – Quizmaster**. Den beskriver det praktiske minimum, en frivillig quizmaster skal kende for at udvikle nye opgaver.

Den autoritative produktbeskrivelse findes i filen:

`01_Byens_Hemmeligheder_Endeligt_Projektgrundlag.md`

Denne manual fokuserer på opgaveproduktion og kvalitet.

## Metodisk hovedreference

Ved design og review skal quizmasteren følge:

`07_Retningslinjer_Escape_Room_Opgavedesign.md`

Filen beskriver blandt andet puzzle-anatomi, mekaniktyper, fairness, kodegenerering, hint-design, narrativ integration, rutestruktur, playtesting og kvalitetskrav. Hvis denne korte manual og metodeguiden overlapper, er metodeguiden den mest detaljerede norm for opgavedesign.

---

# 1. Hvad er en god opgave?

En god opgave er ikke bare et spørgsmål om et sted.

Den skal kombinere:

1. **Sted** – noget spilleren fysisk kan se eller opleve.
2. **Fortælling** – en grund til at være nysgerrig.
3. **Handling** – spilleren skal gøre noget aktivt.
4. **Logik** – sporene fører entydigt til et svar.
5. **Belønning** – løsningen flytter historien fremad.
6. **Sikkerhed** – opgaven kan gennemføres trygt og lovligt.

Den stærkeste tommelfingerregel er:

> Opgaven skal blive dårligere eller umulig, hvis den flyttes til et andet sted.

Hvis opgaven kan løses uændret hjemmefra, er den kun svagt lokationsbaseret.

---

# 2. Data, som GPT'en skal bruge

## A. Researchpakke

Quizmasteren bør levere:

- navn på stedet
- adresse eller koordinater
- kort begrundelse for, hvorfor stedet er interessant
- officielle links og kilder
- gamle billeder, kort eller dokumenter, hvis de må anvendes
- kontaktperson eller institution, hvis relevant

## B. Feltpakke

- præcist foreslået spillerstandpunkt
- GPS-koordinat for standpunktet
- foto i spillerens synsretning
- nærbilleder af relevante detaljer
- gerne kort video eller panorama
- tidspunkt og dato for billederne
- lys- og sæsonforhold
- afstand til det, der skal observeres
- trafik, vand, trapper, skrænter og andre risici
- offentlig adgang og eventuelle åbningstider

## C. Spilpakke

- ønsket sværhedsgrad 1–5
- ønsket varighed
- eksisterende historie eller område
- tidligere og næste opgave
- mulige inventory-genstande
- om opgaven skal kunne stå alene
- særlige krav til skole, familie eller turister

## D. Rettigheder

- hvem har taget billederne?
- må de bruges i appen?
- må historiske billeder reproduceres?
- må AI skabe en illustration baseret på materialet?
- kræver stedet eller en fysisk markør tilladelse?

---

# 3. Hvornår er data gode nok?

## Researchklar

Sted, område og kilder er kendt. GPT'en kan udforske muligheder.

## Udkastklar

Der findes billeder og oplysninger om synlige elementer. GPT'en kan designe en gåde, men må markere usikkerheder.

## Felttestklar

Facit og løsningslogik er dokumenteret, men opgaven skal afprøves på stedet.

## Publiceringsklar

Mennesker har testet opgaven på stedet, og alle åbne punkter er lukket.

---

# 4. Opgavefamilier

## Observation

Spilleren finder et årstal, navn, symbol, antal, farve, form eller forskel.

God til niveau 1–2.

Risiko: bliver en simpel turistquiz.

Forbedring: kombiner observationen med et andet spor eller en fortællingsfunktion.

## Mønstergenkendelse

Spilleren finder gentagelser, rækkefølger eller undtagelser i arkitektur, kunst eller landskab.

God til niveau 2–4.

Risiko: AI-genererede mønstre matcher ikke virkeligheden.

Krav: præcise referencefotos og menneskelig kontrol.

## Kode

Flere verificerede spor bliver til tal, bogstaver eller symboler.

God til niveau 2–5.

Krav: rækkefølgen skal kommunikeres eller kunne udledes entydigt.

## Før og nu

Spilleren sammenligner et historisk billede med stedet.

God til historieformidling.

Risiko: forkert standpunkt, perspektiv eller billedrettigheder.

## Orientering

Spilleren bruger retning, kompas, placering eller bevægelse mellem punkter.

God til natur og større byrum.

Risiko: GPS-præcision og sikkerhed.

## Inventory

En tidligere genstand anvendes til at forstå et nyt spor.

God til sammenhængende historier.

Risiko: komplekse afhængigheder kan blokere spillere.

## Flerlokationsopgave

Spilleren samler oplysninger flere steder.

God til niveau 4–5 og finaler.

Risiko: hvis ét sted er utilgængeligt, kan hele historien blokere.

---

# 5. Typiske fejl

## Flot fortælling, ugyldig gåde

AI kan skabe stemning og UI, selvom facit er opdigtet. Kræv altid løsningsbevis.

## Tvetydig optælling

“Antal vinduer”, “antal bølger” eller “antal søjler” kan fortolkes forskelligt.

Afgræns præcist, hvad der tælles, og test med målgruppen.

## Skjult internetviden

En spiller må ikke være nødt til at google et tal, medmindre appen selv giver kilden eller teksten.

## Uklart standpunkt

Facaden eller kunstværket ser forskelligt ud fra forskellige vinkler.

Angiv et præcist offentligt standpunkt og referencefoto.

## For mange teksttrin

En fysisk oplevelse må ikke blive til læsning af en artikel på telefonen.

## Dekorativ kode

Tallene er valgt, fordi de “ser gode ud”, ikke fordi de kan udledes.

## Hints, der ikke hjælper

“Se bedre efter” er sjældent et godt hint.

## Ustabile spor

Midlertidige skilte, åbningstider, vegetation eller løsøre kan ændre sig.

## Fiktion forklædt som fakta

En dramatisk dagbog må gerne være fiktiv, men det skal fremgå.

---

# 6. Kvalitetsrubrik

Bedøm 1–5:

| Kriterium | 1 | 5 |
|---|---|---|
| Lokationsrelevans | Kun GPS-checkpoint | Kan kun løses netop her |
| Historisk kvalitet | Uklar eller opdigtet | Præcis og kildeunderstøttet |
| Fysisk spor | Usikkert eller skjult | Tydeligt og robust |
| Entydighed | Flere plausible svar | Ét dokumenteret facit |
| Underholdning | Ren faktaquiz | Engagerende puzzle |
| Familiesamarbejde | Én person læser | Flere kan bidrage |
| Sværheds-match | Forkert niveau | Passer klart til niveauet |
| Hint-egnethed | Hjælp afslører eller forvirrer | Tre naturlige trin |
| Sikkerhed | Kræver risikabel adfærd | Trygt offentligt standpunkt |
| Helårsrobusthed | Midlertidigt spor | Stabilt året rundt |
| Historieintegration | Isoleret | Flytter helheden frem |
| UX-egnethed | Teksttung og uklar | Kort og mobilvenlig |

En opgave bør normalt ikke publiceres, hvis:

- entydighed er under 4
- sikkerhed er under 5
- fysisk spor er under 4
- lokationsrelevans er under 3

---

# 7. Familiesamarbejde uden holdkonto

Appen har ikke en formel holdmodel i første version. Familien spiller omkring én telefon.

Opgaven kan stadig skabe samarbejde ved at:

- lade én person læse og andre observere
- placere spor i forskellige dele af synsfeltet
- kombinere en let observation med sværere logik
- give børn og voksne forskellige naturlige roller
- bede spillerne blive enige før indtastning

---

# 8. Helhed i Vejle-piloten

En opgave kan tilhøre:

- Vejle midtby
- havnen og fjorden
- Spinderihallerne og Vestbyen
- Nørreskoven og Skyttehushaven
- Vejle Ådal
- Bredballe og østsiden
- Egtved og bronzealderen
- Jelling

Mulige overordnede rammer:

- et tabt kort over Vejle
- beskeder fra forskellige tidsperioder
- byens fem symboler
- en arkivmappe med manglende sider
- spor efter vandets vej gennem byen
- forbindelsen mellem bakker, fjord, industri og mennesker

En lille opgave bør give mindst én af disse:

- ny historisk viden
- et symbol
- en genstand
- et navn
- en retning
- et kodefragment
- en beslutning, der åbner næste kapitel

---

# 9. Minimumstest med mennesker

Før bred publicering:

- mindst én intern gennemgang
- mindst én faglig faktakontrol ved historisk indhold
- mindst to uafhængige felttests
- børn eller unge fra målgruppen
- mindst én familietest
- test af alle hints
- test af relevante forkerte svar
- test i realistiske lys- og vejrforhold
- kontrol af tekstlængde og trykflader
- kontrol af GPS-radius

Quizmasteren skal registrere:

- hvor spillerne går i stå
- hvad de tror, instruktionen betyder
- hvilke falske svar de finder
- om de kigger på stedet eller telefonen
- om alle kan bidrage
- hvor lang tid opgaven faktisk tager

---

# 10. AI'ens rette rolle

AI er stærk til:

- researchoverblik
- idévariation
- fortælling
- opgavestruktur
- hints
- fejlbeskeder
- UX-tekst
- testcases
- konsistenstjek
- struktureret eksport

AI er mindre pålidelig til:

- præcis fysisk synlighed
- geometriske konturer
- GPS og standpunkt
- adgangsforhold
- aktuelle ændringer på stedet
- billedrettigheder
- sikkerhed
- vurdering af, hvad børn faktisk forstår

Mennesket har det endelige ansvar for publicering.
